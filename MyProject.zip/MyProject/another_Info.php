<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	
	<link rel="stylesheet" href="style_another_Info.css">
	<title>Alex</title>
</head>
<body>
	<canvas></canvas>
	<script type="text/javascript" src="stars.js"></script>
	<div class="form">
		<div class="knowledge">
			<div class="bio"> 
				<p>Просто информация о себе:)</p> 
			</div>
			<p>Просто информация о себе. Любитель потреблять медиаконтент: Сериалы, фильмы, игры, книги. Обучаюсь в колледже на 4-м курсе по направлению "Информационная безопасность" и в тоже время в SKillFactory, и также по направлению "Кибербезопасность". В будущем планирую поступать в ВУЗ на факультет по кибербезопасности, поэтому надеюсь получится:) </p>
		</div>
		<div class="nextPoint"><a href="http://myproject/" ><img src="image/next.png" alt="Before page" style="text-align: center;"></a></div> 
		<!-- Я использовал OpenServer. При использовании другой программы, переключение страниц может слетать:( -->
	</div>
		
</body>
</html>