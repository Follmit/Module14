<?php  
$todayYear = date("Y");

$td = (int) $todayYear; // Конвертируем $todayYear в тип int

const MYYEAR = 2002;

?>

<?php $myAge = $td - MYYEAR ?>
