<hr><div class="avatar"><img src="image/avatar.jpg" style="border: 5xp; border-radius: 100px; width: 90px; ;"></div><hr>

