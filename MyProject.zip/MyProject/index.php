<?php
$startInfo = "Информация обо мне!";
?>

<?php
	$name = 'Alexey';
	$surname = 'Gricenko';
	$myCity = 'MAGADAN';
	$myTelegram = '@Follmit';
	$myStatus = 'Student';
?>

<?php
include 'main.php';
?>

